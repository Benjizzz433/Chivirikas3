## AS Player Opening Menu

scoreboard players add .total ecl_main 0

tellraw @s {"text":""}
tellraw @s [{"text":"========== [","color":"gray","bold":true},{"text":"ECL MENU","color":"gold"},{"text":" ] ==========","color":"gray"}]
tellraw @s [{"text":""},{"text":" - ","color":"gray","bold":true},{"text":"Add a new Loaded Chunk","color":"green","hoverEvent":{"action":"show_text","value":[{"text":"Click","color":"yellow","bold":true,"italic":true}]},"clickEvent":{"action":"run_command","value":"/trigger ecl set 1001"}}]
tellraw @s [{"text":""},{"text":" - ","color":"gray","bold":true},{"text":"Remove a Loaded Chunk","color":"red","hoverEvent":{"action":"show_text","value":[{"text":"Click","color":"yellow","bold":true,"italic":true}]},"clickEvent":{"action":"run_command","value":"/trigger ecl set 1002"}}]
tellraw @s [{"text":""},{"text":" - ","color":"gray","bold":true},{"text":"Toogle Loaded-Chunks Radar ","color":"blue","hoverEvent":{"action":"show_text","value":[{"text":"Click","color":"yellow","bold":true,"italic":true}]},"clickEvent":{"action":"run_command","value":"/trigger ecl set 1003"}},{"text":"(Total Loaded Chunks: ","color":"gray","hoverEvent":{"action":"show_text","value":[{"text":"","color":"yellow","bold":true,"italic":true}]}},{"score":{"name":".total","objective":"ecl_main"},"color":"yellow","hoverEvent":{"action":"show_text","value":[{"text":"","color":"yellow","bold":true,"italic":true}]}},{"text":")","hoverEvent":{"action":"show_text","value":[{"text":"","color":"yellow","bold":true,"italic":true}]}}]
tellraw @s {"text":"==============================","color":"gray","bold":true}
tellraw @s {"text":""}
