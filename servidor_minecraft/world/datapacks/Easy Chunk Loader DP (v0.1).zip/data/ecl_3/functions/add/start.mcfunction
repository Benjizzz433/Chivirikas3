
execute store result score .x ecl_main run data get entity @s Pos[0]
execute store result score .z ecl_main run data get entity @s Pos[2]

scoreboard players operation .xC ecl_main = .x ecl_main
scoreboard players operation .zC ecl_main = .z ecl_main

scoreboard players operation .xC ecl_main /= .16 ecl_main
scoreboard players operation .zC ecl_main /= .16 ecl_main

execute at @s store result score .success ecl_main run forceload add ~ ~

execute if score .success ecl_main matches 1 run scoreboard players add .total ecl_main 1

execute if score .success ecl_main matches 1 run tellraw @s [{"text":"","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]}},{"bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"By XAVI333","color":"dark_purple","bold":true}]},"text":"[ECL] "},{"color":"green","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]},"text":"Added chunk "},{"bold":true,"color":"yellow","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]},"text":"["},{"bold":true,"color":"yellow","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]},"score":{"name":".xC","objective":"ecl_main"}},{"bold":true,"color":"yellow","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]},"text":","},{"bold":true,"color":"yellow","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]},"score":{"name":".zC","objective":"ecl_main"}},{"bold":true,"color":"yellow","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]},"text":"]"},{"color":"green","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]},"text":" successfully!"}]
execute if score .success ecl_main matches 0 run tellraw @s [{"text":"","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]}},{"bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"By XAVI333","color":"dark_purple","bold":true}]},"text":"[ECL] "},{"color":"red","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]},"text":"Chunk "},{"bold":true,"color":"yellow","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]},"text":"["},{"bold":true,"color":"yellow","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]},"score":{"name":".xC","objective":"ecl_main"}},{"bold":true,"color":"yellow","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]},"text":","},{"bold":true,"color":"yellow","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]},"score":{"name":".zC","objective":"ecl_main"}},{"bold":true,"color":"yellow","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]},"text":"]"},{"color":"red","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]},"text":" is already force-loaded!"}]
