## MAIN

# Menu:
    # Display:
        execute as @a[scores={ecl=1..1000}] run function ecl_3:menu

    # Add/Remove:
        execute as @a[scores={ecl=1001}] run function ecl_3:add/start
        execute as @a[scores={ecl=1002}] run function ecl_3:remove/start

    # Radar:
        execute as @a[scores={ecl=1003},tag=!ecl_radar] run function ecl_3:radar/on
        execute as @a[scores={ecl=1003},tag=ecl_radar] run function ecl_3:radar/off

    # Reset:
        execute as @a[scores={ecl=1..}] run scoreboard players set @s ecl 0
        scoreboard players enable @a ecl

# Radar:
    execute as @a[tag=ecl_radar] at @s run function ecl_3:radar/run
