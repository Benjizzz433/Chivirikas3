
title @s actionbar {"text":""}
scoreboard players set @s ecl 0
tag @s remove ecl_radar
