## AS Player With Radar ON

execute store success score .radar ecl_main run forceload query ~ ~

execute if score .radar ecl_main matches 0 run title @s actionbar {"text":"NOT FORCE-LOADED","color":"red","bold":true}
execute if score .radar ecl_main matches 1 run title @s actionbar {"text":"FORCE-LOADED","color":"green","bold":true}
