
scoreboard players set @s ecl 0
tag @s add ecl_radar
