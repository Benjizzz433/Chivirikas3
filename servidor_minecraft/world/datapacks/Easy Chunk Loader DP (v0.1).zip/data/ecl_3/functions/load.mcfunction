## LOAD

# Scoreboards:
    scoreboard objectives add ecl_main dummy
    scoreboard players set .16 ecl_main 16
    scoreboard objectives add ecl trigger

# Enable Title
tellraw @a [{"text":"","hoverEvent":{"action":"show_text","value":[{"text":"","color":"dark_purple","bold":true}]}},{"text":"[ECL] ","color":"gold","bold":true,"hoverEvent":{"action":"show_text","value":[{"text":"By XAVI333","color":"dark_purple","bold":true}]}},{"text":"Enabled! ","color":"green"},{"text":"Use ","color":"gray"},{"text":"/trigger ecl ","color":"yellow","italic":true,"hoverEvent":{"action":"show_text","value":[{"text":"Click","color":"yellow","bold":true,"italic":true}]},"clickEvent":{"action":"run_command","value":"/trigger ecl"}},{"text":"to open the DataPack menu.","color":"gray"}]
